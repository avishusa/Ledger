// src/scripts/poll-inbox.ts
import "dotenv/config";
import { simpleParser } from "mailparser";
import imaps from "imap-simple";
import * as pdfjsLib from "pdfjs-dist/legacy/build/pdf.js";
import { createCanvas } from "canvas";
import { OpenAI } from "openai";
import { prisma } from "../lib/prisma";

// For GPT Vision API
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

(pdfjsLib as any).GlobalWorkerOptions.workerSrc = require("pdfjs-dist/legacy/build/pdf.worker.js");

function getYesterdayStr() {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return d.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).replace(/ /g, "-");
}

async function pdfPageToPngBuffer(uint8array: Uint8Array, pageNum = 1) {
  const doc = await pdfjsLib.getDocument({ data: uint8array }).promise;
  if (pageNum > doc.numPages) throw new Error("Page number out of range");
  const page = await doc.getPage(pageNum);
  const viewport = page.getViewport({ scale: 2.5 });
  const canvas = createCanvas(viewport.width, viewport.height);
  const ctx = canvas.getContext("2d");
  await page.render({ canvasContext: ctx, viewport }).promise;
  return canvas.toBuffer("image/png");
}

async function extractReceiptWithGpt(imageBuffer: Buffer) {
  const prompt = `
Extract the following fields from this retail receipt:
- Store Name
- Transaction Date (YYYY-MM-DD)
- Total Amount
- Payment Method (if visible)
- Category (eg. Grocery, Dining, Fuel, Pharmacy, Electronics, etc)
- Description (short summary of the receipt, if possible)

Respond ONLY as JSON, e.g.:
{"store": "Costco", "date": "2025-07-31", "amount": 135.72, "paymentMethod": "Card", "category": "Wholesale", "description": "Weekly groceries and household items"}

If any field is not clear, write "Unknown" (or 0 for amount).
DO NOT invent information.
`;

  const base64Img = imageBuffer.toString("base64");
  const gptResponse = await openai.chat.completions.create({
    model: "gpt-4o",
    max_tokens: 200,
    messages: [
      {
        role: "user",
        content: [
          { type: "text", text: prompt },
          { type: "image_url", image_url: { url: `data:image/png;base64,${base64Img}` } }
        ]
      }
    ],
    temperature: 0
  });

  let parsed: any = {};
  try {
    const content = gptResponse.choices[0].message.content || "";
    const match = content.match(/```json\s*([\s\S]+?)```/i);
    const jsonStr = match ? match[1] : content;
    parsed = JSON.parse(jsonStr);
  } catch (e) {
    parsed = {};
  }
  return {
    store: typeof parsed["store"] === "string" ? parsed["store"] : "Unknown",
    date: typeof parsed["date"] === "string" ? parsed["date"] : "Unknown",
    amount: typeof parsed["amount"] === "number" ? parsed["amount"] : 0,
    paymentMethod: typeof parsed["paymentMethod"] === "string" ? parsed["paymentMethod"] : "Unknown",
    category: typeof parsed["category"] === "string" ? parsed["category"] : "Unknown",
    description: typeof parsed["description"] === "string" ? parsed["description"] : "",
  };
}

// --------- MAIN SCRIPT ----------
async function main() {
  const config = {
    imap: {
      user: process.env.IMAP_USER,
      password: process.env.IMAP_PASS,
      host: process.env.IMAP_HOST,
      port: 993,
      tls: true,
      authTimeout: 10000,
      tlsOptions: { rejectUnauthorized: false }
    }
  };

  const connection = await imaps.connect(config);
  await connection.openBox("INBOX");

  const searchCriteria = [
    "UNSEEN",
    ["SINCE", getYesterdayStr()]
  ];
  const fetchOptions = { bodies: ['HEADER.FIELDS (FROM TO SUBJECT DATE)'], struct: true };
  const results = await connection.search(searchCriteria, fetchOptions);

  for (const item of results) {
    const all = imaps.getParts(item.attributes.struct);

    for (const part of all) {
      if (
        part.disposition && part.disposition.type === "ATTACHMENT" &&
        (
          (part.subtype && part.subtype.toUpperCase() === "PDF") ||
          (part.params?.name?.toLowerCase().endsWith(".pdf")) ||
          (part.disposition.params?.filename?.toLowerCase().endsWith(".pdf"))
        )
      ) {
        const filename = part.disposition.params?.filename;
        const raw = await connection.getPartData(item, part);
        const uint8array = new Uint8Array(raw);

        // For each page in the PDF
        const doc = await pdfjsLib.getDocument({ data: uint8array }).promise;
        for (let i = 1; i <= doc.numPages; ++i) {
          try {
            const imageBuffer = await pdfPageToPngBuffer(uint8array, i);

            // Extract with GPT
            const result = await extractReceiptWithGpt(imageBuffer);

            const {
              store = "Unknown",
              date = "Unknown",
              amount = 0,
              paymentMethod = "Unknown",
              category = "Unknown",
              description = ""
            } = result;

            // Only parse YYYY-MM-DD, else fallback to today
            let parsedDate = new Date();
            if (date && /^\d{4}-\d{2}-\d{2}$/.test(date)) {
              parsedDate = new Date(date);
            }

            // Insert into ledger
            const ledger = await prisma.ledger.create({
              data: {
                date: parsedDate,
                merchant: store || "Unknown",
                amount: typeof amount === "number" && !isNaN(amount) ? amount : 0,
                description: description || "",
                paymentMethod: paymentMethod || "Unknown",
                category: category || "Unknown",
              }
            });

            await prisma.ingestLog.create({
              data: {
                status: "success",
                message: `Parsed receipt for ${store || "Unknown"} on page ${i}`,
                fileName: filename,
                ledgerId: ledger.id,
              }
            });

          } catch (e) {
            await prisma.ingestLog.create({
              data: {
                status: "error",
                message: `Failed to extract page ${i}: ${e}`,
                fileName: filename
              }
            });
          }
        }
      }
    }
    // Mark as seen
    const uid = item.attributes.uid;
    connection.addFlags(uid, "\\Seen", () => { });
  }

  await connection.end();
  console.log("IMAP poller finished.");
}

// Poll forever
async function pollLoop() {
  while (true) {
    try {
      await main();
    } catch (err) {
      console.error("Poll error:", err);
    }
    await new Promise(res => setTimeout(res, 2 * 60 * 1000)); // 2 min
  }
}
pollLoop();
